export default async function handler(req, res) {
  try {
    const { input } = req.body;

    const response = await fetch(
      "https://api.groq.com/openai/v1/chat/completions",
      {
        method: "POST",
        headers: {
          "Authorization": "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",
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          model: "llama-3.3-70b-versatile",
          messages: [
            {
              role: "system",
              content: "You are Mohsin AI Quizzer. Answer quiz questions clearly and correctly."
            },
            {
              role: "user",
              content: input
            }
          ]
        })
      }
    );

    const data = await response.json();
    res.status(200).json(data);

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}